#!/bin/bash
cd $HOME/exiftool-termux
python2 sac.py

