#!/bin/env python2
import os

amma = raw_input("Enter your filename :- ")
os.system("perl exiftool " + amma)
