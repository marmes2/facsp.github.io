#!/bin/bash
apt-get update -y
apt-get upgrade -y
apt-get install perl -y
apt-get install python2 -y
cd $HOME
cd exiftool-termux
chmod +x exiftool
chmod +x sac.py
chmod +x sac.sh
cd /data/data/com.termux/files/usr/bin
rm -rf exiftool
cd $HOME
cd exiftool-termux
ln -s $HOME/exiftool-termux/sac.sh /data/data/com.termux/files/usr/bin/exiftool
echo
echo
echo "Just execute exiftool  "
